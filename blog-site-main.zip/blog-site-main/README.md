# Basic Blog App

## Used

- Scroll Animation: https://michalsnik.github.io/aos/
- CSS Library: https://getbootstrap.com/


## View


![basic-site](https://user-images.githubusercontent.com/113799443/216645600-52b36c76-23a0-49f3-9f30-7eb27835129b.gif)

